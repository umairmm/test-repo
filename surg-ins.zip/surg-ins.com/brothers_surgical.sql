-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2015 at 04:39 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `brothers_surgical`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(6, 'Anesthesia'),
(5, 'Dental'),
(1, 'Surgical');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `article_code` varchar(20) DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `size` varchar(30) NOT NULL,
  `description` longtext,
  `image_path` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `article_code`, `type`, `size`, `description`, `image_path`) VALUES
(1, 'OPERATING SCISSORS ', 'wg-12-12', '1', '11 to 20cm', 'Surgical scissors are used for cutting and dissecting tissues. They also cut bandages and sutures. Each procedure has a separate pair of scissors that is used to complete it. Surgical scissors are required in any surgery and have value and durability not seen in regular scissors.', '1_operating_scissors_str_13cm.jpg'),
(4, 'OPERATING SCISSORS ', 'wg-12-12', '1', '11 to 20cm', 'Surgical scissors are used for cutting and dissecting tissues. They also cut bandages and sutures. Each procedure has a separate pair of scissors that is used to complete it. Surgical scissors are required in any surgery and have value and durability not seen in regular scissors.', '2_OPERATING SCISSORS STR 14.5CM SHARP_BLUNT.jpg'),
(7, 'Dental Syringe', 'wg-12-12', '5', '11 to 20cm', 'Surgical scissors are used for cutting and dissecting tissues. They also cut bandages and sutures. Each procedure has a separate pair of scissors that is used to complete it. Surgical scissors are required in any surgery and have value and durability not seen in regular scissors.', '112. Dental Syringe.jpg'),
(8, 'TC OPERATING SCISSORS STRAIGHT  ', '', '1', '11 Cm To 20 Cm', 'Surgical scissors are used for cutting and dissecting tissues. They also cut bandages and sutures. Each procedure has a separate pair of scissors that is used to complete it. Surgical scissors are required in any surgery and have value and durability not seen in regular scissors.', '3. TC OPERATING SCISSORS STRAIGHT 14.5CM BLUNT_BLUNT.jpg'),
(9, ' LEXTER BABY SCISSORS CURVED', '', '1', '11 Cm To 26 Cm', 'Surgical scissors are used for cutting and dissecting tissues. They also cut bandages and sutures. Each procedure has a separate pair of scissors that is used to complete it. Surgical scissors are required in any surgery and have value and durability not seen in regular scissors.', '4. LEXTER BABY SCISSORS CURVED 10CM BLUNT_BLUNT.jpg'),
(10, 'MILTEX METZENBAUM SCISSORS CVD', '', '1', '11 Cm To 26 Cm', 'Surgical scissors are used for cutting and dissecting tissues. They also cut bandages and sutures. Each procedure has a separate pair of scissors that is used to complete it. Surgical scissors are required in any surgery and have value and durability not seen in regular scissors.', '5. MILTEX METZENBAUM SCISSORS CVD 14CM BLUNT_BLUNT.jpg'),
(11, 'TC METZENAUM CURVED SCISSORS', 'wg-12-12', '1', '11 Cm To 26 Cm', 'Metzenbaum scissors have matching ends and include short-curved or long-blunt designs. The former is used for cutting superficial, delicate tissues, while the latter is built for cutting deep, delicate tissues.', '6.   TC METZENAUM CURVED SCISSORS 11.5CM B_B.png'),
(12, 'POTTS SMITH SCISSORS', '', '1', '11 Cm To 26 Cm', 'This instrument is used for the cutting of vascular delicate tissues. ends and include short-curved or long-blunt designs. The former is used for cutting superficial, delicate tissues, while the latter is built for cutting deep.', '7.  POTTS SMITH SCISSORS 19CM ANGLED 40 S_S TIP.jpg'),
(13, ' TC IRIS SCISSORS ', '', '1', '14 Cm To 18 Cm', 'Iris scissors have slightly curved or angled, sharp blades that are 3 to 4 inches long. They generally are used for ophthalmic surgeries. The handles are circular to fit snugly around the finger and thumb, and they stem off of a central pin, where the blades pivot. For surgical purposes', '9. TC IRIS SCISSORS.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
